```
 ____         __  __
| __ ) _   _ / _|/ _| ___ _ __
|  _ \| | | | |_| |_ / _ \ '__|
| |_) | |_| |  _|  _|  __/ |
|____/ \__,_|_| |_|  \___|_|
```

Explanation for lights_off:
Using gdb, I came across the line "sub $0x50,%rsp" which indicated that 80 bytes were being subtracted out to make room for the size of the buffer. This meant that I needed to allocate 80 bytes of padding to then overflow the buffer, so I placed 80 "00" bytes into my lights.txt file. Then I accounted for the 8 bytes for the return address, which also filled in 8 "00" bytes in my lights.txt file. Finally, I wrote the address of the lights_off function in little endian at the end of the lights.txt file to overflow the buffer and redirect it there instead of returning back to test exploit so the lights_off function could run.

Explanation for sandwiches:
Similarly to lights_off, the beginning of the code comprises of the same 80 bytes
for the buffer size, 8 for the return, and the return address corresponding to the beginning of sandwich_order. Now the program must feed in the values of the
sandwich_id and sammich_types array to then run sandwich order and pass the conditions. The sandwich_id corresponds to the cookie, and according to the psuedocode, the four values of the sammich_types array must add up to 33. Following this, I wrote the cookie and four random integer values which add to 33 
in my sandwiches.txt file, which then satisfied the running of sandwich_order and find_total (which added the four values to 33).

Explanation for lost:
To solve this, I created an assembly code file to write the exploit function. This
function solved the tasks of moving the cooking to the %rax (meant for returning) and pushing the address of the line after the getbuf to make it seem like the program would continue as normal. Then the exploit function would just return. When the machine code was assembled and disassembled, it generated the lost.d file, which contained the hex code needed to be placed at the beginning of the bytes in the lost.txt file. This is because that once the addressed of the initial rbp and new rbp are written, the program has to return to the start of the buffer to then run the exploit code instead of just returning back to test_exploit and continuing normally. 

Explanation for Fraudster:
This was very similar to lost excluding two details. The first is that the buffer size is now 544 bytes rather than 80. The second is that there is now stack randomization, so NOP sleds now need to be used to take into account for rsp appearing at random location and always direct the stack towards the machine code, and then back into the NOP sled so the code can be return five times. The exploit code is similar apart from having to adjust 16 bytes between rsp and rbp (8 bytes for the old rbp, 8 bytes for the return). The exploit string itself consisted of 526 NOP bytes (90), 18 bytes for the machine code, 8 more dummy bytes for the rbp value, and the final 8 bytes reserved for the return address. I determined the return address by going into my NOP sled and subtracting from the initial return address from rsp far back enough so it could guarantee that my program would always return into the NOP sled, especially since it is ran 5 times.