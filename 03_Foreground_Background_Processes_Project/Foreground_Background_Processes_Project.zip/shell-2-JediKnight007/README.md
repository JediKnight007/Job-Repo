```
 ____  _          _ _   ____
/ ___|| |__   ___| | | |___ \
\___ \| '_ \ / _ \ | |   __) |
 ___) | | | |  __/ | |  / __/
|____/|_| |_|\___|_|_| |_____|
```
The process I had for shell 2 is split amongst many helper functions, but can be broken down into
the main componenets of instantiation, determining foreground/background, parsing, signaling/reaping,
and fg/bg. Similarly to shell 1, the program needs to parse input statements into tokens and arguments,
which are fed into execv. This is done through two arrays argv and argv2, which tokenize the input command
into the necessary individual components (found in launch_job). The program also needs to determine if the
process occurs in the foreground or background (indicated by an & char on the end of an input). This is done
in execute_command(), where the & is identified and the integer is_background is set to 1 if the & exists. 
If the background process is occuring, the launch_job() function includes the code to add a job to the list,
incremeent the global job id variable (does not need to decrement even if job is removed, the jid just needs
to be unique per job). Once thats done, the background signal calling is done in the "reap_jobs()" function, where
it is determined if the program exited normally, was stopped, will continue, or a WIFSIGNALED. If the process run
is in the foreground, a waitpid is called, which suspends the calling process until a child process ends/stops. Then
the foreground reaping occurs, in which a call for WIFSIGNALED or WIFSTOPPED is checked for with the status input, and 
termination or suspension calls are accordingly made/printed (stopped job means a job is added to job list). Finally,
fg and bg is accounted for in the execute_command function via strncmp(input, "fg %", 4) and strncmp(input, "bg %", 4),
, atio is used to extract the jid, and the pid is found via get_job_jid. The process uses kill(-pid, SIGCONT) to send
a signal to resume the process and run the same reaping calls as the normal processes (except foreground also runs an
WIFEXITED(status) call because it has to remove the job process established by the original background process).