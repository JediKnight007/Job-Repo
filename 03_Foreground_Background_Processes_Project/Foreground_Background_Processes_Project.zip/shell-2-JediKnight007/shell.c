#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include "./jobs.h"

void setup_signal_handlers() {
    signal(SIGINT, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
}

void reset_child_signal_handlers() {
    signal(SIGINT, SIG_DFL);
    signal(SIGTSTP, SIG_DFL);
    signal(SIGTTOU, SIG_DFL);
}

void parse_input(char *input, char **argv, char **argv2);
void remove_address(char **argv4, char *token);
void reap_jobs(job_list_t *job_list);
void foreground_job(job_list_t *job_list, int jid);
void background_job(job_list_t *job_list, int jid);

int global_jid = 1;

char *find_address(char **argv4) {
    char *token;
    int count = 0;
    int command = 0;
    while (argv4[count] != NULL) {
        if (strrchr(argv4[count], '/') != NULL) {
            command = 1;
            token = argv4[count];
            break;
        }
        count++;
    }
    if (command != 1) {
        token = NULL;
    }
    return token;
}

void launch_job(job_list_t *job_list, char *command, int is_background) {
    char *argv[256 / 2 + 1];
    char *argv2[256 / 2 + 1];
    memset(argv, '\0', sizeof(argv));
    memset(argv2, '\0', sizeof(argv));
    parse_input(command, argv, argv2);
    char *token = find_address(argv2);
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        return;
    }
    if (pid == 0) {
        setpgid(0, 0);
        if (!is_background)
            tcsetpgrp(STDIN_FILENO, getpid());
        reset_child_signal_handlers();
        if (token != NULL) {
            if (execv(token, argv) < 0) {
                perror("execv failed");
                exit(EXIT_FAILURE);
            }
        }
    } else {
        if (is_background) {
            add_job(job_list, global_jid, pid, RUNNING, command);
            printf("[%d] (%d)\n", global_jid, pid);
            global_jid++;
        } else {
            int status;
            waitpid(pid, &status, WUNTRACED);
            if (WIFSIGNALED(status)) {
                printf("(%d) terminated by signal %d\n", pid, WTERMSIG(status));
            } else if (WIFSTOPPED(status)) {
                printf("[%d] (%d) suspended by signal %d\n", global_jid, pid,
                       WSTOPSIG(status));
                add_job(job_list, global_jid, pid, STOPPED, command);
                global_jid++;
            }
            tcsetpgrp(STDIN_FILENO, getpgrp());
        }
    }
}

void parse_input(char *input, char **argv, char **argv2) {
    char *token = strtok(input, " \t\n");
    int i = 0;
    while (token != NULL) {
        argv2[i] = token;
        i++;
        token = strtok(NULL, " \t\n");
    }
    fflush(stdout);
    argv2[i] = NULL;
    int count = 0;
    int count2 = 0;
    int isSym = 0;
    char *tok;
    char ch = 'A';
    tok = &ch;
    while (argv2[count] != NULL) {
        tok = argv2[count];
        if (strrchr(tok, '/') != NULL && isSym == 0) {
            tok = strrchr(tok, '/') + 1;
            if (strcmp(tok, "") == 0) {
                tok = NULL;
            }
            isSym = 1;
        }
        argv[count2] = tok;
        count++;
        count2++;
    }
    argv[count] = NULL;
}

void reap_jobs(job_list_t *job_list) {
    int status;
    pid_t pid;

    while ((pid = waitpid(-1, &status, WNOHANG | WUNTRACED | WCONTINUED)) > 0) {
        int jid = get_job_jid(job_list, pid);
        if (WIFEXITED(status)) {
            printf("[%d] (%d) terminated with exit status %d\n", jid, pid,
                   WEXITSTATUS(status));
            remove_job_jid(job_list, jid);
        } else if (WIFSIGNALED(status)) {
            printf("[%d] (%d) terminated by signal %d\n", jid, pid,
                   WTERMSIG(status));
            remove_job_jid(job_list, jid);
        } else if (WIFSTOPPED(status)) {
            printf("[%d] (%d) suspended by signal %d\n", jid, pid,
                   WSTOPSIG(status));
            update_job_jid(job_list, jid, STOPPED);
        } else if (WIFCONTINUED(status)) {
            printf("[%d] (%d) resumed\n", jid, pid);
            update_job_jid(job_list, jid, RUNNING);
        }
    }
}

void execute_command(job_list_t *job_list, char *input) {
    int is_background = 0;
    size_t len = strlen(input);

    if (len > 0 && input[len - 1] == '&') {
        is_background = 1;
        input[len - 1] = '\0';
    }

    if (strncmp(input, "fg %", 4) == 0) {
        int jid = atoi(input + 4);
        foreground_job(job_list, jid);
    } else if (strncmp(input, "bg %", 4) == 0) {
        int jid = atoi(input + 4);
        background_job(job_list, jid);
    } else {
        launch_job(job_list, input, is_background);
    }
    reap_jobs(job_list);
}

void foreground_job(job_list_t *job_list, int jid) {
    pid_t pid = get_job_pid(job_list, jid);
    if (pid == -1) {
        fprintf(stderr, "Job ID %d not found.\n", jid);
        return;
    }
    if (kill(-pid, SIGCONT) < 0) {
        perror("kill failed\n");
    }

    tcsetpgrp(STDIN_FILENO, pid);
    int status;
    if (waitpid(pid, &status, WUNTRACED) > 0) {
        if (WIFSTOPPED(status)) {
            printf("[%d] (%d) suspended by signal %d\n", jid, pid,
                   WSTOPSIG(status));
            update_job_jid(job_list, jid, STOPPED);
        } else if (WIFSIGNALED(status)) {
            printf("(%d) terminated by signal %d\n", pid, WTERMSIG(status));
            remove_job_jid(job_list, jid);
        } else if (WIFEXITED(status)) {
            remove_job_jid(job_list, jid);
        }
        tcsetpgrp(STDIN_FILENO, getpgrp());
    }
}

void background_job(job_list_t *job_list, int jid) {
    pid_t pid = get_job_pid(job_list, jid);
    if (pid == -1) {
        fprintf(stderr, "Job ID %d not found.\n", jid);
        return;
    }
    if (kill(-pid, SIGCONT) < 0) {
        perror("kill failed\n");
    }
    update_job_jid(job_list, jid, RUNNING);
}

int main() {
    setup_signal_handlers();
    job_list_t *job_list = init_job_list();
    char command[256];
    ssize_t bytes_read;
    while (1) {
        // printf("33sh>");
        fflush(stdout);
        bytes_read = read(STDIN_FILENO, command, sizeof(command));
        if (bytes_read < 0) {
            cleanup_job_list(job_list);
            exit(EXIT_FAILURE);
        } else if (bytes_read == 0) {
            break;
        }
        command[strcspn(command, "\n")] = '\0';
        if (strcmp(command, "") == 0) {
            reap_jobs(job_list);
            continue;
        }
        if (strcmp(command, "exit") == 0) {
            cleanup_job_list(job_list);
            exit(EXIT_SUCCESS);
        } else if (strcmp(command, "jobs") == 0) {
            jobs(job_list);
        } else {
            execute_command(job_list, command);
        }
    }

    cleanup_job_list(job_list);
    return 0;
}
