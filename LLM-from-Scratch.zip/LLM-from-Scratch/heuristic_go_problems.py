import torch
from typing import Optional, Any, Union
import numpy as np
from go_search_problem import GoState, HeuristicGoProblem
BLACK = 0
WHITE = 1

def get_features(game_state):
    """
    Convert a GoState OR dataset dict entry into a flattened
    feature vector for the neural network.

    Handles both:
      • GoState object (from gameplay)
      • dict entries from dataset_5x5 (with key 'board')
    """
    if isinstance(game_state, GoState):
        board = game_state.get_board()      

    elif isinstance(game_state, dict):
        board = game_state["board"]        
    else:
        raise TypeError(f"Unsupported game_state type: {type(game_state)}")
    features = board.flatten().astype(float).tolist()
    return features

class GoProblemSimpleHeuristic(HeuristicGoProblem):
    def __init__(self, size: int = 5, state=None, player_to_move: int = 0):
        super().__init__(size=size, state=state, player_to_move=player_to_move)

    def heuristic(self, state, player_index):
        """
        Very simple heuristic that just compares the number of pieces for each player
        
        Having more pieces than the opponent means that some were captured, capturing is generally good.
        Returns value from BLACK's perspective: positive = good for BLACK, negative = good for WHITE.
        """
        black_stones = len(state.get_pieces_coordinates(BLACK))
        white_stones = len(state.get_pieces_coordinates(WHITE))

        return black_stones - white_stones

    def __str__(self) -> str:
        return "Simple Heuristic"


class GoProblemLearnedHeuristic(HeuristicGoProblem):
    def __init__(self, model=None, size: int = 5, state=None, player_to_move: int = 0):
        super().__init__(size=size, state=state, player_to_move=player_to_move)
        self.model = model

    def encoding(self, state):
        features = get_features(state)
        return features

    def heuristic(self, state, player_index):
        features = self.encoding(state)
        x = torch.tensor(features, dtype=torch.float32)
        
        with torch.no_grad():
            v = self.model(x).squeeze().item()

        if player_index == WHITE:
            v = -v

        return v
    def __str__(self) -> str:
        return "Learned Heuristic"
