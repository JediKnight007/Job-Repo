import os
import sys
import importlib.util
import random
import time
from abc import ABC, abstractmethod
from typing import Optional, Tuple, Any, List
from heuristic_go_problems import GoProblemSimpleHeuristic, GoProblemLearnedHeuristic
import numpy as np
import torch
from torch import nn

from go_search_problem import GoProblem, GoState, Action, HeuristicGoProblem
from heuristic_go_problems import GoProblemSimpleHeuristic
from models import ValueNetwork, load_model
from adversarial_search import minimax as hw3_minimax, alpha_beta as hw3_alpha_beta, alpha_beta_time_limited

MAXIMIZER = 0
MIMIZER = 1

class SearchTimeout(Exception):
    """Raised when search runs out of allotted time."""
    pass

class GameAgent(ABC):
    """Abstract base class for all Go game agents."""
    
    @abstractmethod
    def get_move(self, state: GoState, time_limit: float) -> Action:
        """Get the best move for the given state within the time limit.
        
        Args:
            state: Current game state
            time_limit: Maximum time in seconds to spend on this move
            
        Returns:
            Action index representing the chosen move
        """
        pass

    def reset(self):
        """Reset any internal state of the agent if necessary.
            Called after a new game is started.
        """
        pass


class RandomAgent(GameAgent):
    # An Agent that makes random moves

    def __init__(self):
        self.search_problem = GoProblem()

    def get_move(self, game_state: GoState, time_limit: float) -> Action:
        """
        get random move for a given state
        """
        actions = self.search_problem.get_available_actions(game_state)
        return random.choice(actions)

    def __str__(self):
        return "RandomAgent"


class GreedyAgent(GameAgent):
    def __init__(self, search_problem=GoProblemSimpleHeuristic()):
        super().__init__()
        self.search_problem = search_problem

    def get_move(self, game_state: GoState, time_limit: float) -> Action:
        """
        get move of agent for given game state.
        Greedy agent looks one step ahead with the provided heuristic and chooses the best available action
        (Greedy agent does not consider remaining time)

        Args:
            game_state (GameState): current game state
            time_limit (float): time limit for agent to return a move
        """
        # Create new GoSearchProblem with provided heuristic
        search_problem = self.search_problem

        # Player 0 is maximizing
        if game_state.player_to_move() == MAXIMIZER:
            best_value = -float('inf')
        else:
            best_value = float('inf')
        best_action = None

        # Get Available actions
        actions = search_problem.get_available_actions(game_state)

        # Compare heuristic of every reachable next state
        for action in actions:
            new_state = search_problem.transition(game_state, action)
            value = search_problem.heuristic(new_state, new_state.player_to_move())
            if game_state.player_to_move() == MAXIMIZER:
                if value > best_value:
                    best_value = value
                    best_action = action
            else:
                if value < best_value:
                    best_value = value
                    best_action = action

        # Return best available action
        return best_action

    def __str__(self):
        """
        Description of agent (Greedy + heuristic/search problem used)
        """
        return "GreedyAgent + " + str(self.search_problem)

#############################################
# 
#
# Part 1: Basic Adversarial Search Algorithms
#
#
#############################################

class GoHW3Adapter:
    """
    Adapter that makes our Go heuristic problem look like the HW3
    HeuristicAdversarialSearchProblem expected by minimax / alpha_beta.

    - get_start_state() returns the GoState we want to search from
    - heuristic(state) is evaluated from BLACK's perspective (player 0)
    """

    def __init__(self, base_problem: HeuristicGoProblem, root_state: GoState):
        self.base = base_problem
        self._start_state = root_state

    def get_start_state(self) -> GoState:
        return self._start_state

    def get_available_actions(self, state: GoState):
        return self.base.get_available_actions(state)

    def transition(self, state: GoState, action: Action) -> GoState:
        return self.base.transition(state, action)

    def is_terminal_state(self, state: GoState) -> bool:
        return self.base.is_terminal_state(state)

    def get_result(self, state: GoState) -> float:
        return self.base.get_result(state)

    def heuristic(self, state: GoState) -> float:
        return self.base.heuristic(state, MAXIMIZER)


class MinimaxAgent(GameAgent):
    def __init__(self, depth_cutoff=1, search_problem=GoProblemSimpleHeuristic()):
        super().__init__()
        self.depth = depth_cutoff
        self.search_problem = search_problem

    def get_move(self, game_state: GoState, time_limit: float) -> Action:
        """
        Get move of agent for given game state using minimax algorithm

        MinimaxAgents should not consider time limit, they simply search to their specified depth_cutoff
        If your agent is running out of time, you should use a shorter cutoff depth
        Args:
            game_state (GameState): current game state
            time_limit (float): time limit for agent to return a move
        Returns:
            best_action (Action): best action for current game state
        """
        asp = GoHW3Adapter(self.search_problem, game_state)
        best_action, stats = hw3_minimax(asp, cutoff_depth=self.depth)
        return best_action

    def __str__(self):
        return f"MinimaxAgent w/ depth {self.depth} + " + str(self.search_problem)


class AlphaBetaAgent(GameAgent):
    def __init__(self, depth_cutoff=1, search_problem=GoProblemSimpleHeuristic()):
        super().__init__()
        self.depth = depth_cutoff
        self.search_problem = search_problem

    def get_move(self, game_state: GoState, time_limit: float) -> Action:
        """
        Get move of agent for given game state using alpha-beta algorithm

        AlphaBetaAgents should not consider time limit, they simply search to their specified depth_cutoff
        If your agent is running out of time, you should use a shorter cutoff depth

        Args:
            game_state (GameState): current game state
            time_limit (float): time limit for agent to return a move
        Returns:
            best_action (Action): best action for current game state
        """
        asp = GoHW3Adapter(self.search_problem, game_state)
        best_action, stats = hw3_alpha_beta(asp, cutoff_depth=self.depth)
        return best_action

    def __str__(self):
        return f"AlphaBeta w/ depth {self.depth} + " + str(self.search_problem)



def create_value_agent_from_model():
    """
    Create agent object from saved model. 
    This (or other methods like this) will be how your agents will be created in gradescope and in the final tournament.

    In the game_runner file, there is a factory function that will call this function to create an agent.
    You can run games with your agent against other agents by running game_runner.py with the appropriate command line arguments.
    """
    model_path = "value_model.pt"

    feature_size = 100
    model = load_model(model_path, ValueNetwork(feature_size))
    heuristic_search_problem = GoProblemLearnedHeuristic(model)
    learned_agent = GreedyAgent(heuristic_search_problem)

    return learned_agent


################################################
#
# Part 2: Advanced Adversarial Search Algorithms
#
################################################

class IterativeDeepeningAgent(GameAgent):
    def __init__(self, cutoff_time=1, search_problem=GoProblemSimpleHeuristic()):
        super().__init__()
        self.cutoff_time = cutoff_time
        self.search_problem = search_problem

    def get_move(self, game_state, time_limit):
        """
        Get move of agent for given game state using iterative deepening algorithm (+ alpha-beta).
        Iterative deepening is a search algorithm that repeatedly searches for a solution to a problem,
        increasing the depth of the search with each iteration.

        The advantage of iterative deepening is that you can stop the search based on the time limit, rather than depth.
        The recommended approach is to modify your implementation of Alpha-beta to stop when the time limit is reached
        and run IDS on that modified version.

        Args:
            game_state (GameState): current game state
            time_limit (float): time limit for agent to return a move
        Returns:
            best_action (Action): best action for current game state
        """
        max_time = min(time_limit, self.cutoff_time)
        start_time = time.time()
        asp = GoHW3Adapter(self.search_problem, game_state)

        best_action = None
        depth = 1
        SAFETY_BUFFER = 0.1  

        while True:
            elapsed = time.time() - start_time
            remaining = max_time - elapsed
            
            if remaining <= SAFETY_BUFFER:
                break
            
            action, stats, completed = alpha_beta_time_limited(
                asp, 
                cutoff_depth=depth,
                start_time=start_time,
                time_limit=max_time - SAFETY_BUFFER
            )
            
            if completed and action is not None:
                best_action = action
                depth += 1
            else:
                break
        if best_action is None:
            actions = self.search_problem.get_available_actions(game_state)
            best_action = random.choice(actions) if actions else None

        return best_action

    def __str__(self):
        return f"IterativeDeepneing + " + str(self.search_problem)
    

class MCTSNode:
    def __init__(self, state, parent=None, children=None, action=None):
        # GameState for Node
        self.state = state

        # Parent (MCTSNode)
        self.parent = parent
        
        # Children List of MCTSNodes
        if children is None:
            children = []
        self.children = children
        
        # Number of times this node has been visited in tree search
        self.visits = 0
        
        # Value of node (number of times simulations from children results in black win)
        self.value = 0
        
        # Action that led to this node
        self.action = action

    def __hash__(self):
        """
        Hash function for MCTSNode is hash of state
        """
        return hash(self.state)
    
class MCTSAgent(GameAgent):
    def __init__(self, c=np.sqrt(2)):
        """
        Args: 
            c (float): exploration constant of UCT algorithm
        """
        super().__init__()
        self.c = c
        self.search_problem = GoProblem()
        self.root = None

    def get_move(self, game_state: GoState, time_limit: float) -> Action:
        """
        Get move of agent for given game state using MCTS algorithm
        """
        start_time = time.time()

        def _safe_current_player(state: GoState) -> int:
            try:
                if hasattr(state, "internal_state"):
                    return int(state.internal_state.current_player())
            except Exception:
                return -999
            try:
                return int(state.player_to_move())
            except Exception:
                return -999

        def _is_terminal_safe(state: GoState) -> bool:
            if _safe_current_player(state) < 0:
                return True
            return self.search_problem.is_terminal_state(state)

        def _obs(state: GoState) -> Optional[np.ndarray]:
            if _is_terminal_safe(state):
                return None
            if hasattr(state, "internal_state"):
                return np.array(state.internal_state.observation_tensor(), dtype=np.float32)
            return np.array(state.observation_tensor(), dtype=np.float32)

        def _same_state(a: GoState, b: GoState) -> bool:
            oa = _obs(a)
            ob = _obs(b)
            if oa is None or ob is None:
                return False
            return oa.shape == ob.shape and np.array_equal(oa, ob)

        def _get_obs_planes(state: GoState):
            if hasattr(state, "internal_state"):
                obs = state.internal_state.observation_tensor()
            else:
                obs = state.observation_tensor()
            size = state.size if hasattr(state, "size") else int(np.sqrt(len(obs) / 4))
            planes = np.array(obs, dtype=np.float32).reshape((4, size, size))
            return planes, size

        if _is_terminal_safe(game_state):
            return 0
        root_player = int(game_state.player_to_move())  

        planes, size = _get_obs_planes(game_state)
        occupied = int(np.sum(planes[0] > 0.5) + np.sum(planes[1] > 0.5))
        frac = occupied / float(size * size)

        if frac < 0.25:
            base_budget = 0.25
        elif frac < 0.65:
            base_budget = 0.45
        else:
            base_budget = 0.80

        per_move_budget = min(base_budget, max(0.05, time_limit * 0.15))
        max_time = max(0.0, per_move_budget)

        root_actions = self.search_problem.get_available_actions(game_state)
        if not root_actions:
            return 0

        pass_action = size * size
        if self.root is not None and self.root.children:
            reused = None
            for ch in self.root.children:
                if _same_state(ch.state, game_state):
                    ch.parent = None
                    reused = ch
                    break
            root = reused if reused is not None else MCTSNode(game_state.clone())
        else:
            root = MCTSNode(game_state.clone())

        self.root = root

        def is_adjacent_to_stone(state: GoState, action: int) -> bool:
            if action is None:
                return False
            if _is_terminal_safe(state):
                return False
            planes_s, sz = _get_obs_planes(state)
            if action == sz * sz:
                return False
            r = action // sz
            c = action % sz
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                rr, cc = r + dr, c + dc
                if 0 <= rr < sz and 0 <= cc < sz:
                    if planes_s[0, rr, cc] > 0.5 or planes_s[1, rr, cc] > 0.5:
                        return True
            return False

        def _order_actions(state: GoState, actions: List[int]) -> List[int]:
            if pass_action in actions:
                non_pass = [a for a in actions if a != pass_action]
            else:
                non_pass = list(actions)

            adj = []
            non_adj = []
            for a in non_pass:
                (adj if is_adjacent_to_stone(state, a) else non_adj).append(a)
            return adj + non_adj + ([pass_action] if pass_action in actions else [])

        def uct_value(parent: MCTSNode, child: MCTSNode) -> float:
            if child.visits == 0:
                return float("inf")
            exploit = child.value / child.visits
            explore = self.c * np.sqrt(np.log(max(1, parent.visits)) / child.visits)
            return exploit + explore

        def select(node: MCTSNode) -> MCTSNode:
            curr = node
            while curr.children:
                if _is_terminal_safe(curr.state):
                    return curr
                curr = max(curr.children, key=lambda ch: uct_value(curr, ch))
            return curr

        def expand(leaf: MCTSNode):
            if _is_terminal_safe(leaf.state):
                return [leaf]
            if leaf.children:
                return leaf.children

            actions = self.search_problem.get_available_actions(leaf.state)
            if not actions:
                return [leaf]

            if leaf.visits < 5:
                K = 8
            elif leaf.visits < 20:
                K = 16
            else:
                K = 24

            ordered = _order_actions(leaf.state, actions)
            ordered = ordered[:min(K, len(ordered))]

            children = []
            for act in ordered:
                next_state = self.search_problem.transition(leaf.state, act)
                child = MCTSNode(state=next_state, parent=leaf, action=act)
                leaf.children.append(child)
                children.append(child)
            return children

        def rollout_policy(state: GoState, step: int) -> Action:
            actions = self.search_problem.get_available_actions(state)
            if not actions:
                return 0

            if pass_action in actions:
                non_pass = [a for a in actions if a != pass_action]
                if non_pass:
                    actions = non_pass

            if step < 2:
                good = [a for a in actions if is_adjacent_to_stone(state, a)]
                if good and random.random() < 0.60:
                    return random.choice(good)

            return random.choice(actions)

        def rollout_from_state(state: GoState) -> float:
            #OpenSpiel results +1 black win, -1 white win, 0 draw.
            if _is_terminal_safe(state):
                result = self.search_problem.get_result(state)
            else:
                s = state.clone()
                max_steps = 2 * (size * size + 1)
                steps = 0

                while (not _is_terminal_safe(s)) and steps < max_steps:
                    if time.time() - start_time > max_time:
                        break
                    acts = self.search_problem.get_available_actions(s)
                    if not acts:
                        break
                    a = rollout_policy(s, steps)
                    s = self.search_problem.transition(s, a)
                    steps += 1

                result = self.search_problem.get_result(s)

            if result == 0:
                return 0.5
            if root_player == 0:  
                return 1.0 if result == 1 else 0.0
            else:               
                return 1.0 if result == -1 else 0.0

        def simulate(children):
            return [rollout_from_state(child.state) for child in children]

        def backpropagate(rewards, children):
            for child, reward in zip(children, rewards):
                curr = child
                while curr is not None:
                    curr.visits += 1

                    cp = _safe_current_player(curr.state)
                    if cp < 0:
                        break
                    if cp == root_player:
                        curr.value += reward
                    else:
                        curr.value += (1.0 - reward)

                    curr = curr.parent


        while time.time() - start_time < max_time:
            if time.time() - start_time > max_time:
                break
            leaf = select(root)
            children = expand(leaf)
            rewards = simulate(children)
            backpropagate(rewards, children)

        if not root.children:
            return random.choice(root_actions)

        best_child = max(root.children, key=lambda ch: (ch.visits, ch.value / max(1, ch.visits)))
        return best_child.action


    def __str__(self):
        return "MCTS"
    

###################################################
#
# Part 3: Final Agent
#
###################################################

def get_final_agent_5x5():
    """Called to construct agent for final submission for 5x5 board"""
    return None

def get_final_agent_9x9():
    """Called to construct agent for final submission for 9x9 board"""
    return MCTSAgent()
