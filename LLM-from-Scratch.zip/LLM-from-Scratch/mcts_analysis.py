import numpy as np
import matplotlib.pyplot as plt

from go_search_problem import GoProblem
from agents import MCTSAgent

def run_mcts_analysis(time_limit: float = 1.0):
    problem = GoProblem(size=5)
    state = problem.start_state
    agent = MCTSAgent()
    agent.get_move(state, time_limit=time_limit)
    root = agent.root
    if root is None:
        print("No root tree built")
        return
    size = 5
    grid = np.zeros((size, size))

    for child in root.children:
        action = child.action
        if action is None:
            continue
        if action == size * size:
            continue
        r = action // size
        c = action % size
        grid[r, c] = child.visits

    plt.imshow(grid, cmap="viridis")
    plt.colorbar(label="# of visits")
    plt.title(f"MCTS root visits (time_limit = {time_limit}s)")
    plt.xlabel("Column")
    plt.ylabel("Row")
    plt.gca().invert_yaxis()
    plt.show()

if __name__ == "__main__":
    run_mcts_analysis(time_limit=1.0)
