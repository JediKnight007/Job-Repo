class SelfDestructException(Exception):
    pass

class KoException(Exception):
    pass

class InvalidInputException(Exception):
    pass