from typing import Dict, Tuple, Optional, Union
import time

from adversarial_search_problem import (
    Action,
    State as GameState,
)
from heuristic_adversarial_search_problem import HeuristicAdversarialSearchProblem


def minimax(asp: HeuristicAdversarialSearchProblem[GameState, Action], cutoff_depth: float = float('inf')) -> Tuple[Action, Dict[str, int]]:
    """
    Implement the minimax algorithm for adversarial search problems.
    
    Minimax is a recursive algorithm used for finding the optimal move in two-player,
    zero-sum games. It assumes both players play optimally by maximizing their own
    score and minimizing their opponent's score.

    Args:
        asp: A HeuristicAdversarialSearchProblem representing the game.
        cutoff_depth: Maximum search depth (0 = start state, 1 = one move ahead).
                     Uses heuristic evaluation when cutoff is reached.

    Returns:
        Tuple containing:
            - Best action to take from the current state
            - Dictionary with search statistics including 'states_expanded'
    """
    best_action = None
    stats = {
        'states_expanded': 0
    }
    start = asp.get_start_state()
    starting_move = asp.get_available_actions(start)
    if not starting_move:
        return None, stats
    
    def minimax_value(current_state: GameState, current_depth: int) -> float:
        if asp.is_terminal_state(current_state):
            final = float(asp.get_result(current_state))
            return final
        if current_depth >= cutoff_depth:
            h = float(asp.heuristic(current_state))
            return h
        if current_state.player_to_move() == 0:
            return max_value(current_state, current_depth)
        else:
            return min_value(current_state, current_depth)

    def max_value(current_state: GameState, current_depth: int) -> float:
        v = float('-inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        for i in moves:
            state_max = asp.transition(current_state, i)
            v = max(v, minimax_value(state_max, current_depth + 1))
        return v

    def min_value(current_state: GameState, current_depth: int) -> float:
        v = float('inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        for j in moves:
            state_min = asp.transition(current_state, j)
            v = min(v, minimax_value(state_min, current_depth + 1))
        return v
    
    if start.player_to_move() != 0:
        score = float('inf')
        for i in starting_move:
            node = asp.transition(start, i)
            min_val = minimax_value(node, 1)
            if min_val < score:
                score, best_action = min_val, i
    else:
        score = float('-inf')
        for i in starting_move:
            node = asp.transition(start, i)
            max_val = minimax_value(node, 1)
            if max_val > score:
                score, best_action = max_val, i
        
    return best_action, stats


def alpha_beta(asp: HeuristicAdversarialSearchProblem[GameState, Action], cutoff_depth: float = float('inf')) -> Tuple[Action, Dict[str, int]]:
    """
    Implements the alpha-beta pruning algorithm for adversarial search.
    
    Alpha-beta pruning is an optimization of the minimax algorithm that eliminates
    branches that cannot possibly influence the final decision. It maintains two
    values (alpha and beta) representing the best options found so far for the
    maximizing and minimizing players respectively.

    Args:
        asp: A HeuristicAdversarialSearchProblem representing the game.
        cutoff_depth: Maximum search depth (0 = start state, 1 = one move ahead).
                     Uses heuristic evaluation when cutoff is reached.

    Returns:
        Tuple containing:
            - Best action to take from the current state
            - Dictionary with search statistics including 'states_expanded'
    """
    best_action = None
    stats = {
        'states_expanded': 0 
    }
    start = asp.get_start_state()
    starting_move = asp.get_available_actions(start)
    if not starting_move:
        return None, stats
    a = float('-inf')
    b = float('inf')
    
    def ab_pruning(current_state: GameState, current_depth: int, a: float, b: float) -> float:
        if asp.is_terminal_state(current_state):
            return float(asp.get_result(current_state))
        if current_depth >= cutoff_depth:
            return float(asp.heuristic(current_state))
        if current_state.player_to_move() == 0:
            return max_value(current_state, current_depth, a, b)
        else:
            return min_value(current_state, current_depth, a, b)

    def max_value(current_state: GameState, current_depth: int, a: float, b: float) -> float:
        v = float('-inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        for i in moves:
            state_max = asp.transition(current_state, i)
            v = max(v, ab_pruning(state_max, current_depth + 1, a, b))
            a = max(a, v)
            if v >= b:
                break
        return v

    def min_value(current_state: GameState, current_depth: int, a: float, b: float) -> float:
        v = float('inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        for j in moves:
            state_min = asp.transition(current_state, j)
            v = min(v, ab_pruning(state_min, current_depth + 1, a, b))
            b = min(b, v)
            if v <= a:  
                break
        return v
    
    if start.player_to_move() != 0:
        score = float('+inf')
        for i in starting_move:
            node = asp.transition(start, i)
            min_val = ab_pruning(node, 1, a, b)
            if min_val < score:
                score, best_action = min_val, i
            b = min(b, score)
    else:
        score = float('-inf')
        for i in starting_move:
            node = asp.transition(start, i)
            max_val = ab_pruning(node, 1, a, b)
            if max_val > score:
                score, best_action = max_val, i
            a = max(a, score)
    
    return best_action, stats


def alpha_beta_time_limited(asp: HeuristicAdversarialSearchProblem[GameState, Action], 
                             cutoff_depth: float = float('inf'),
                             start_time: float = None,
                             time_limit: float = float('inf')) -> Tuple[Action, Dict[str, int], bool]:
    """
    Alpha-beta pruning with time limit checks.
    
    This version checks if time is running out before each recursive call and
    can interrupt the search early, returning the best action found so far.
    
    Args:
        asp: A HeuristicAdversarialSearchProblem representing the game.
        cutoff_depth: Maximum search depth.
        start_time: Time when search started (from time.time()).
        time_limit: Maximum time allowed for this search in seconds.
        
    Returns:
        Tuple containing:
            - Best action to take from the current state
            - Dictionary with search statistics
            - Boolean indicating if search completed (True) or timed out (False)
    """
    if start_time is None:
        start_time = time.time()
    
    best_action = None
    stats = {
        'states_expanded': 0,
        'timed_out': False
    }
    
    start = asp.get_start_state()
    starting_move = asp.get_available_actions(start)
    if not starting_move:
        return None, stats, True
    
    a = float('-inf')
    b = float('inf')
    
    def time_remaining():
        """Check if we have time remaining"""
        return (time.time() - start_time) < time_limit
    
    def ab_pruning(current_state: GameState, current_depth: int, a: float, b: float) -> Optional[float]:
        """Returns None if time expired, otherwise returns the value"""
        if not time_remaining():
            stats['timed_out'] = True
            return None
            
        if asp.is_terminal_state(current_state):
            return float(asp.get_result(current_state))
        if current_depth >= cutoff_depth:
            return float(asp.heuristic(current_state))
        if current_state.player_to_move() == 0:
            return max_value(current_state, current_depth, a, b)
        else:
            return min_value(current_state, current_depth, a, b)

    def max_value(current_state: GameState, current_depth: int, a: float, b: float) -> Optional[float]:
        if not time_remaining():
            stats['timed_out'] = True
            return None
            
        v = float('-inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        
        for i in moves:
            state_max = asp.transition(current_state, i)
            result = ab_pruning(state_max, current_depth + 1, a, b)
            if result is None:  
                return None
            v = max(v, result)
            a = max(a, v)
            if v >= b:
                break
        return v

    def min_value(current_state: GameState, current_depth: int, a: float, b: float) -> Optional[float]:
        if not time_remaining():
            stats['timed_out'] = True
            return None
            
        v = float('inf')
        moves = asp.get_available_actions(current_state)
        stats['states_expanded'] += 1
        
        for j in moves:
            state_min = asp.transition(current_state, j)
            result = ab_pruning(state_min, current_depth + 1, a, b)
            if result is None:  
                return None
            v = min(v, result)
            b = min(b, v)
            if v <= a:  
                break
        return v
    
    if start.player_to_move() != 0:
        score = float('+inf')
        for i in starting_move:
            if not time_remaining():
                stats['timed_out'] = True
                break
            node = asp.transition(start, i)
            min_val = ab_pruning(node, 1, a, b)
            if min_val is None:  
                break
            if min_val < score:
                score, best_action = min_val, i
            b = min(b, score)
    else:
        score = float('-inf')
        for i in starting_move:
            if not time_remaining():
                stats['timed_out'] = True
                break
            node = asp.transition(start, i)
            max_val = ab_pruning(node, 1, a, b)
            if max_val is None:  
                break
            if max_val > score:
                score, best_action = max_val, i
            a = max(a, score)
    
    completed = not stats['timed_out']
    return best_action, stats, completed