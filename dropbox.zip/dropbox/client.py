##
## client.py - Dropbox client implementation
##

# ** Optional libraries, uncomment if you need them **
# Search "python <name> library" for documentation
#import string  # Python library with useful string constants
#import dacite  # Helpers for serializing dicts into dataclasses
#import pymerkle # Merkle tree implementation (CS1620/CS2660 only, but still optional)

## ** Support code libraries ****
# The following imports load our support code from the "support"
# directory.  See the Dropbox wiki for usage and documentation.
import support.crypto as crypto                   # Our crypto library
import support.util as util                       # Various helper functions

# These imports load instances of the dataserver, keyserver, and memloc classes
# to use in your client. See the Dropbox Wiki and setup guide for examples.
from support.dataserver import dataserver, memloc, Memloc
from support.keyserver import keyserver

# **NOTE**:  If you want to use any additional libraries, please ask on Ed
# first.  You are NOT permitted to use any additional cryptographic functions
# other than those provided by crypto.py, or any filesystem/networking libraries.

#########################################################################################

# helper functions
def convert_to_memloc(arbitrary_string: str) -> Memloc:
    return memloc.MakeFromBytes(crypto.Hash(arbitrary_string.encode())[:16])

def check_file_in_list(filename, file_list):
    for file_entry in file_list:
        if file_entry['filename'] == filename:
            return file_entry
    return None

def find_and_decrypt_file_metadata(memloc_location, symmetric_key):
    try:
        encrypted_metadata = dataserver.Get(memloc_location)
        if encrypted_metadata is None:
            return None
        decrypted_bytes = crypto.SymmetricDecrypt(symmetric_key, encrypted_metadata)
        decrypted_metadata = util.BytesToObject(decrypted_bytes)
        return decrypted_metadata
    except Exception as e:
        raise util.DropboxError("Failed to retrieve or decrypt file metadata") from e
    
def share_needed_info(self, filename, sender, recipient, memloc_location, file_symmetric_key):
    # NEED to create block of plaintext and hmac_tag to send to common memloc

    # necessary components to put data into block memloc
    key_mac = crypto.HashKDF(file_symmetric_key, "authentication")

    # create plaintext (need to encrypt with reciepient's public key)
    recipient_public_key = keyserver.Get(f"key-{recipient}")
    if recipient_public_key is None:
        raise util.DropboxError("Recipient does not exist")
    encrypted_symmetric_key = crypto.AsymmetricEncrypt(recipient_public_key, file_symmetric_key)

    plaintext = {
        "location": memloc_location,
        "symmetric_key": encrypted_symmetric_key,
        "filename": filename
    }
    plaintext_bytes = util.ObjectToBytes(plaintext)

    # create HMAC tag
    hmac_tag = crypto.HMAC(key_mac, plaintext_bytes)

    # encrypt key_mac with sender's public key
    encrypted_key_mac = crypto.AsymmetricEncrypt(recipient_public_key, key_mac)

    # create the block to store in common memloc
    block = {
        "plaintext": plaintext_bytes,
        "hmac": hmac_tag,
        "encrypted_key_mac": encrypted_key_mac
    }
    block_bytes = util.ObjectToBytes(block)

    # store block in common memloc; format is sender + recipient + filename
    common_memloc = convert_to_memloc(sender + recipient + filename)
    dataserver.Set(common_memloc, block_bytes)

    # update on dataserver
    update_metadata(self)

def update_metadata(self):
    user_memloc = convert_to_memloc(self.username)
    user_data = dataserver.Get(user_memloc)
    encrypted_metadata, salt = util.BytesToObject(user_data)

    # user metadata, updated
    user_metadata = {
        "username": self.username,
        "password": self.password,
        "private_key_bytes": self.private_key_bytes,
        "file_list": self.file_list,
        "validation": self.validation
    }
    iv = crypto.SecureRandom(16)
    encrypted_metadata = crypto.SymmetricEncrypt(crypto.PasswordKDF(self.password, salt, keyLen=16), iv, util.ObjectToBytes(user_metadata))

    # store the updated metadata and the same salt back in the dataserver
    dataserver.Set(user_memloc, util.ObjectToBytes([encrypted_metadata, salt]))

#########################################################################################

class User:
    def __init__(self, username, password) -> None:
        """
        Class constructor for the `User` class.

        You are free to add fields to the User class by changing the definition
        of this function.
        """

        # salt and iv for encryption
        salt = crypto.SecureRandom(16)
        iv = crypto.SecureRandom(16)

        # master key derived from password and salt
        master_key = crypto.PasswordKDF(password, salt, keyLen=16)

        # extra keys for the user, serialized to bytes for storage
        public_key, private_key = crypto.AsymmetricKeyGen()
        private_key_bytes = bytes(private_key)
        
        # lists for files
        file_list = []

        # validation field to ensure user is valid
        validation = "valid"

        # setting up metadata, encrypt with user's master key
        self.username = username
        self.password = password
        self.private_key_bytes = private_key_bytes
        self.file_list = file_list
        self.validation = validation
        user_metadata = {
            "username": self.username,
            "password": self.password,
            "private_key_bytes": self.private_key_bytes,
            "file_list": self.file_list,
            "validation": self.validation
        }
        encrypted_metadata = crypto.SymmetricEncrypt(master_key, iv, util.ObjectToBytes(user_metadata))
        metadata_plus_salt = util.ObjectToBytes([encrypted_metadata, salt])

        # unique address for each user
        user_memloc = convert_to_memloc(username)
        dataserver.Set(user_memloc, metadata_plus_salt)

        # storing public key on keyserver
        keyserver.Set(f"key-{username}", public_key)

    def upload_file(self, filename: str, data: bytes) -> None:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/storage/upload-file.html
        """
        
        # check if the file is in list of files
        file = check_file_in_list(filename, self.file_list)
        if file is not None:
            # go to memloc location, decrypt file metadata
            memloc_location = file['memloc']
            file_symmetric_key = file['symmetric_key']
            file_metadata = find_and_decrypt_file_metadata(memloc_location, file_symmetric_key)

            # get necessary components to put data into block memloc
            key_enc = crypto.HashKDF(file_symmetric_key, "encryption")
            key_mac = crypto.HashKDF(file_symmetric_key, "authentication")
            iv = crypto.SecureRandom(16)

            # encrypt file data, get HMAC
            ciphertext = crypto.SymmetricEncrypt(key_enc, iv, data)
            hmac_tag = crypto.HMAC(key_mac, ciphertext)

            # block dictionary
            block = {
                "ciphertext": ciphertext,
                "hmac": hmac_tag
            }
            block_bytes = util.ObjectToBytes(block)

            # replace list of components with block memloc
            file_metadata['list_of_components'] = [block_bytes]

            # store the changes on the dataserver
            encrypted_metadata = crypto.SymmetricEncrypt(file_symmetric_key, iv, util.ObjectToBytes(file_metadata))
            dataserver.Set(memloc_location, encrypted_metadata)
            update_metadata(self)

        else:
            # create memloc w username and filename
            memloc_location = convert_to_memloc(self.username + filename)

            # create symmetric key for file
            file_symmetric_key = crypto.SecureRandom(16)

            # store dictionary of all info in file_list and add to user's file list
            file_entry = {
                "filename": filename,
                "memloc": memloc_location,
                "symmetric_key": file_symmetric_key,
                "owner": self.username
            }
            self.file_list.append(file_entry)

            # get necessary components to put data into block memloc
            key_enc = crypto.HashKDF(file_symmetric_key, "encryption")
            key_mac = crypto.HashKDF(file_symmetric_key, "authentication")
            iv = crypto.SecureRandom(16)

            # encrypt file data, get HMAC
            ciphertext = crypto.SymmetricEncrypt(key_enc, iv, data)
            hmac_tag = crypto.HMAC(key_mac, ciphertext)

            # block
            block = {
                "ciphertext": ciphertext,
                "hmac": hmac_tag
            }
            block_bytes = util.ObjectToBytes(block)

            # create file metadata
            file_metadata = {
                "filename": filename,
                "symmetric_key": file_symmetric_key,
                "iv": iv,
                "who_has_access": [],
                "list_of_components": [block_bytes]
            }

            # update metadata in dataserver
            encrypted_metadata = crypto.SymmetricEncrypt(file_symmetric_key, iv, util.ObjectToBytes(file_metadata))
            dataserver.Set(memloc_location, encrypted_metadata)
            update_metadata(self)

    def download_file(self, filename: str) -> bytes:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/storage/download-file.html
        """
        # check if the file is in list of files
        file = check_file_in_list(filename, self.file_list)
        if file is None:
            raise util.DropboxError("File does not exist")
        
        # go to memloc location and decrypt file metadata
        memloc_location = file['memloc']
        file_symmetric_key = file['symmetric_key']
        file_metadata = find_and_decrypt_file_metadata(memloc_location, file_symmetric_key)
        
        # iterate through list_of_components and download
        all_data = b""
        for block_bytes in file_metadata['list_of_components']:
            block = util.BytesToObject(block_bytes)
            ciphertext = block['ciphertext']
            hmac_tag = block['hmac']

            # verify HMAC
            key_mac = crypto.HashKDF(file_symmetric_key, "authentication")
            computed_hmac = crypto.HMAC(key_mac, ciphertext)
            if not crypto.HMACEqual(hmac_tag, computed_hmac):
                raise util.DropboxError("HMAC check failed — integrity violation")

            # decrypt the ciphertext
            key_enc = crypto.HashKDF(file_symmetric_key, "encryption")
            decrypted_data = crypto.SymmetricDecrypt(key_enc, ciphertext)

            # add to all_data
            all_data += decrypted_data
        
        return all_data

    def append_file(self, filename: str, data: bytes) -> None:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/storage/append-file.html
        """
        # TODO: Implement

        # get file
        file = check_file_in_list(filename, self.file_list)
        if file is None:
            raise util.DropboxError("File does not exist")
        
        # go to memloc location and decrypt file metadata
        memloc_location = file['memloc']
        file_symmetric_key = file['symmetric_key']
        file_metadata = find_and_decrypt_file_metadata(memloc_location, file_symmetric_key)

        # put data into block memloc
        key_enc = crypto.HashKDF(file_symmetric_key, "encryption")
        key_mac = crypto.HashKDF(file_symmetric_key, "authentication")
        iv = crypto.SecureRandom(16)

        # encrypt file data, get HMAC
        ciphertext = crypto.SymmetricEncrypt(key_enc, iv, data)
        hmac_tag = crypto.HMAC(key_mac, ciphertext)

        # block dictionary
        block = {
            "ciphertext": ciphertext,
            "hmac": hmac_tag
        }
        block_bytes = util.ObjectToBytes(block)

        # append block to list of components in file metadata
        file_metadata['list_of_components'].append(block_bytes)

        # store the changes on the dataserver
        encrypted_metadata = crypto.SymmetricEncrypt(file_symmetric_key, iv, util.ObjectToBytes(file_metadata))
        dataserver.Set(memloc_location, encrypted_metadata)

    def share_file(self, filename: str, recipient: str) -> None:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/sharing/share-file.html
        """
        # TODO: Implement
        
        # check if the file is in list of files AND that you are the owner of the file
        file = check_file_in_list(filename, self.file_list)
        if file is None:
            raise util.DropboxError("File does not exist")
        if file['owner'] != self.username:
            raise util.DropboxError("You are not the owner of this file")
        
        # go to memloc location and decrypt file metadata
        memloc_location = file['memloc']
        file_symmetric_key = file['symmetric_key']
        file_metadata = find_and_decrypt_file_metadata(memloc_location, file_symmetric_key)

        # check if recipient is already in who_has_access
        if recipient in file_metadata['who_has_access']:
            raise util.DropboxError("Recipient already has access to this file")
        
        # add recipient to who_has_access
        file_metadata['who_has_access'].append(recipient)

        # reflect change in file metadata by storing on datasrever
        dataserver.Set(memloc_location, crypto.SymmetricEncrypt(file_symmetric_key, file_metadata['iv'], util.ObjectToBytes(file_metadata)))

        # share the needed info with recipient
        share_needed_info(self, filename, self.username, recipient, memloc_location, file_symmetric_key)

    def receive_file(self, filename: str, sender: str) -> None:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/sharing/receive-file.html
        """
        # TODO: Implement

        # get data from common memloc
        common_memloc = convert_to_memloc(sender + self.username + filename)
        try:
            block_bytes = dataserver.Get(common_memloc)
            if block_bytes is None:
                raise util.DropboxError("No shared file found")
        except ValueError:
            raise util.DropboxError("No shared file found")
        
        # check HMAC integrity
        block = util.BytesToObject(block_bytes)
        plaintext_bytes = block['plaintext']
        hmac_tag = block['hmac']
        encrypted_key_mac = block['encrypted_key_mac']
        
        # get key_mac from encrypted key_mac
        my_private_key = crypto.AsymmetricDecryptKey.from_bytes(self.private_key_bytes)
        key_mac = crypto.AsymmetricDecrypt(my_private_key, encrypted_key_mac)

        # verify HMAC
        computed_hmac = crypto.HMAC(key_mac, plaintext_bytes)
        if not crypto.HMACEqual(hmac_tag, computed_hmac):
            raise util.DropboxError("HMAC check failed — integrity violation")
        
        file = check_file_in_list(filename, self.file_list)

        # if filename already exists in user's file list
        if file is not None:
            # if this is the EXACT same file, update because a revoke has happened
            if file['owner'] == sender:
                # decrypt new symmetric key
                plaintext = util.BytesToObject(plaintext_bytes)
                new_symmetric_key = crypto.AsymmetricDecrypt(my_private_key, plaintext['symmetric_key'])

                # replace field "symmetric_key" in file entry with new symmetric key
                file['symmetric_key'] = new_symmetric_key

                # update metadata in dataserver
                update_metadata(self)
            
            # otherwise, raise an error because the user already has a file with that name
            else:
                raise util.DropboxError("You already have a file with that name from a different sender")
        
        # otherwise, file does not exist in user's file list, so we can add it
        else:
            # decrypt symmetric key
            plaintext = util.BytesToObject(plaintext_bytes)
            symmetric_key = crypto.AsymmetricDecrypt(my_private_key, plaintext['symmetric_key'])

            # store the dictionary in file_list
            file_entry = {
                "filename": filename,
                "memloc": plaintext['location'],
                "symmetric_key": symmetric_key,
                "owner": sender
            }
            self.file_list.append(file_entry)

            # reflect change in the dataserver by updating the user's metadata
            update_metadata(self)

    def revoke_file(self, filename: str, old_recipient: str) -> None:
        """
        The specification for this function is at:
        https://brown-csci1660.github.io/dropbox-wiki/client-api/sharing/revoke-file.html
        """
        # TODO: Implement

        # check if the file is in list of files AND that you are the owner of the file
        file = check_file_in_list(filename, self.file_list)
        if file is None:
            raise util.DropboxError("File does not exist")
        if file['owner'] != self.username:
            raise util.DropboxError("You are not the owner of this file")
        
        # go to memloc location and decrypt file metadata
        memloc_location = file['memloc']
        file_symmetric_key = file['symmetric_key']
        key_enc = crypto.HashKDF(file_symmetric_key, "encryption")
        key_mac = crypto.HashKDF(file_symmetric_key, "authentication")
        file_metadata = find_and_decrypt_file_metadata(memloc_location, file_symmetric_key)

        # remove old_recipient from who_has_access
        if old_recipient not in file_metadata['who_has_access']:
            raise util.DropboxError("Recipient does not have access to this file")
        file_metadata['who_has_access'].remove(old_recipient)

        # change symmetric key for file
        new_file_symmetric_key = crypto.SecureRandom(16)
        new_key_enc = crypto.HashKDF(new_file_symmetric_key, "encryption")
        new_key_mac = crypto.HashKDF(new_file_symmetric_key, "authentication")
        iv = crypto.SecureRandom(16)

        # iterate through list_of_components and re-encrypt everything
        for block in file_metadata['list_of_components']:
            block_data = util.BytesToObject(block)
            ciphertext = block_data['ciphertext']
            hmac_tag = block_data['hmac']

            # verify HMAC
            computed_hmac = crypto.HMAC(key_mac, ciphertext)
            if not crypto.HMACEqual(hmac_tag, computed_hmac):
                raise util.DropboxError("HMAC check failed — integrity violation")

            # decrypt the ciphertext
            decrypted_data = crypto.SymmetricDecrypt(key_enc, ciphertext)

            # re-encrypt the data with the new symmetric key
            new_ciphertext = crypto.SymmetricEncrypt(new_key_enc, iv, decrypted_data)
            new_hmac_tag = crypto.HMAC(new_key_mac, new_ciphertext)

            # update the block with the new ciphertext and HMAC
            block_data['ciphertext'] = new_ciphertext
            block_data['hmac'] = new_hmac_tag
        
        # now overwrite file metadata with the new symmetric key and updated list_of_components
        # by changing the contents in the memloc location in the dataserver

        # update in your file list the new symmetric key
        file_metadata['symmetric_key'] = new_file_symmetric_key

        # encrypt and store metadata in dataserver
        encrypted_metadata = crypto.SymmetricEncrypt(new_file_symmetric_key, iv, util.ObjectToBytes(file_metadata))
        dataserver.Set(memloc_location, encrypted_metadata)

        # now we need to give the new symmetric keys to the remaining recipients
        # call share_needed_info to share the new symmetric key with each remaining recipient
        for recipient in file_metadata['who_has_access']:
            share_needed_info(self, filename, self.username, recipient, memloc_location, new_file_symmetric_key)

def create_user(username: str, password: str) -> User:
    """
    The specification for this function is at:
    https://brown-csci1660.github.io/dropbox-wiki/client-api/authentication/create-user.html
    """
    # check for empty username
    if username == "":
        raise util.DropboxError("Username cannot be empty")

    # get memloc for this user
    user_memloc = convert_to_memloc(username)

    # check if user already exists
    try:
        dataserver.Get(user_memloc)
        raise util.DropboxError("Username already exists")
    except ValueError:
        pass

    # make the User object
    new_user = User(username, password)
    return new_user

def authenticate_user(username: str, password: str) -> User:
    """
    The specification for this function is at:
    https://brown-csci1660.github.io/dropbox-wiki/client-api/authentication/authenticate-user.html
    """
    # TODO: Implement
    user_memloc = convert_to_memloc(username)
    try:
        user_data = dataserver.Get(user_memloc)
    except ValueError:
        raise util.DropboxError("User does not exist")

    try:
        encrypted_metadata, salt = util.BytesToObject(user_data)
    except Exception:
        raise util.DropboxError("Corrupted user record")

    master_key = crypto.PasswordKDF(password, salt, keyLen=16)

    try:
        decrypted_bytes = crypto.SymmetricDecrypt(master_key, encrypted_metadata)
        decrypted_metadata = util.BytesToObject(decrypted_bytes)
    except Exception:
        raise util.DropboxError("Incorrect password or decryption failed")

    if decrypted_metadata.get("validation") != "valid":
        raise util.DropboxError("Incorrect password or user is invalid")

    user = User.__new__(User)
    user.username = decrypted_metadata["username"]
    user.password = decrypted_metadata["password"]
    user.private_key_bytes = decrypted_metadata["private_key_bytes"]
    user.file_list = decrypted_metadata["file_list"]
    user.validation = decrypted_metadata["validation"]

    return user
