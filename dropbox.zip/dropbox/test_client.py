##
## test_client.py - Test for your client
##
##

import unittest
import string

import support.crypto as crypto
import support.util as util

from support.dataserver import dataserver, memloc
from support.keyserver import keyserver

# Import your client
import client as c

# Use this in place of the above line to test using the reference client
#import dropbox_client_reference as c


class ClientTests(unittest.TestCase):
    def setUp(self):
        """
        This function is automatically called before every test is run. It
        clears the dataserver and keyserver to a clean state for each test case.
        """
        dataserver.Clear()
        keyserver.Clear()

    def test_create_user(self):
        """
        Checks user creation.
        """
        u = c.create_user("usr", "pswd")
        u2 = c.authenticate_user("usr", "pswd")

        self.assertEqual(vars(u), vars(u2))

    def test_upload(self):
        """
        Tests if uploading a file throws any errors.
        """
        u = c.create_user("usr", "pswd")
        u.upload_file("file1", b'testing data')

    def test_overwrite_file(self):
        """
        Tests if overwriting data in an existing file works correctly.
        """
        u = c.create_user("usr", "pswd")

        initial_data = b'initial data'
        u.upload_file("file1", initial_data)

        downloaded_data = u.download_file("file1")
        self.assertEqual(downloaded_data, initial_data)

        new_data = b'new data'
        u.upload_file("file1", new_data)

        downloaded_data_after_overwrite = u.download_file("file1")
        self.assertEqual(downloaded_data_after_overwrite, new_data)

    def test_download(self):
        """
        Tests if a downloaded file has the correct data in it.
        """
        u = c.create_user("usr", "pswd")

        data_to_be_uploaded = b'testing data'

        u.upload_file("file1", data_to_be_uploaded)
        downloaded_data = u.download_file("file1")

        self.assertEqual(downloaded_data, data_to_be_uploaded)

    def test_share_and_download(self):
        """
        Simple test of sharing and downloading a shared file.
        """
        u1 = c.create_user("usr1", "pswd")
        u2 = c.create_user("usr2", "pswd")

        u1.upload_file("shared_file", b'shared data')
        u1.share_file("shared_file", "usr2")

        u2.receive_file("shared_file", "usr1")
        down_data = u2.download_file("shared_file")

        self.assertEqual(down_data, b'shared data')

    def test_download_error(self):
        """
        Simple test that tests that downloading a file that doesn't exist
        raise an error.
        """
        u = c.create_user("usr", "pswd")

        # NOTE: When using `assertRaises`, the code that is expected to raise an
        #       error needs to be passed to `assertRaises` as a lambda function.
        self.assertRaises(util.DropboxError, lambda: u.download_file("file1"))

    def test_append_file(self):
        """
        Tests if appending data to a file works correctly.
        """
        u = c.create_user("usr", "pswd")

        initial_data = b'initial data'
        u.upload_file("file1", initial_data)

        appended_data = b' appended data'
        u.append_file("file1", appended_data)

        downloaded_data = u.download_file("file1")
        self.assertEqual(downloaded_data, initial_data + appended_data)

    def test_revoke_file(self):
        """
        Tests if revoking access to a file works correctly.
        """
        u1 = c.create_user("usr1", "pswd")
        u2 = c.create_user("usr2", "pswd")

        u1.upload_file("shared_file", b'shared data')
        u1.share_file("shared_file", "usr2")

        u2.receive_file("shared_file", "usr1")

        down_data = u2.download_file("shared_file")
        self.assertEqual(down_data, b'shared data')

        u1.revoke_file("shared_file", "usr2")

        self.assertRaises(util.DropboxError, lambda: u2.download_file("shared_file"))

    def test_advanced_revoke_file(self):
        """
        Tests revoking access for one user while ensuring other users still have access.
        """
        u1 = c.create_user("usr1", "pswd")
        u2 = c.create_user("usr2", "pswd")
        u3 = c.create_user("usr3", "pswd")

        u1.upload_file("shared_file", b'shared data')
        u1.share_file("shared_file", "usr2")
        u1.share_file("shared_file", "usr3")

        u2.receive_file("shared_file", "usr1")
        u3.receive_file("shared_file", "usr1")

        down_data_u2 = u2.download_file("shared_file")
        down_data_u3 = u3.download_file("shared_file")
        self.assertEqual(down_data_u2, b'shared data')
        self.assertEqual(down_data_u3, b'shared data')

        u1.revoke_file("shared_file", "usr2")

        u3.receive_file("shared_file", "usr1")
        down_data_u3_after_revoke = u3.download_file("shared_file")
        self.assertEqual(down_data_u3_after_revoke, b'shared data')

        self.assertRaises(util.DropboxError, lambda: u2.download_file("shared_file"))

# Start the REPL if this file is launched as the main program
if __name__ == '__main__':
    clienttests = ClientTests()
    clienttests.setUp()
    clienttests.test_create_user()
    print("test_create_user passed")

    clienttests.setUp()
    clienttests.test_upload()
    print("test_upload passed")

    clienttests.setUp()
    clienttests.test_overwrite_file()
    print("test_overwrite_file passed")

    clienttests.setUp()
    clienttests.test_download()
    print("test_download passed")

    clienttests.setUp()
    clienttests.test_share_and_download()
    print("test_share_and_download passed")

    clienttests.setUp()
    clienttests.test_download_error()
    print("test_download_error passed")

    clienttests.setUp()
    clienttests.test_append_file()
    print("test_append_file passed")

    clienttests.setUp()
    clienttests.test_revoke_file()
    print("test_revoke_file passed")

    clienttests.setUp()
    clienttests.test_advanced_revoke_file()
    print("test_advanced_revoke_file passed")