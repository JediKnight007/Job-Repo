```
 ____  _          _ _   _
/ ___|| |__   ___| | | / |
\___ \| '_ \ / _ \ | | | |
 ___) | | | |  __/ | | | |
|____/|_| |_|\___|_|_| |_|
```

The program is split into three major parts: parsing, built-in function redirecting, and symbol redirecting. The parsing portion is done in the parse_input function, which creates two lists (argv and argv2), argv2 with each token (path names, redirection symbols, and commands), and argv with just command names. The purpose of this is for when execv has to fun, and the specificed path and specific commands can be run properly. The needed path is found through the find_address function by searching the first instance of a "/" in the argv2 array. Once parsing is done and the address is found for execv, built-in functions cd, ln, rm, or exit are searched for, and if they are found, are checked to see if the following commands are formatted properly, and if they are the functions are properly executed. If they are not formatted properly, fprintf flags are printed, representing error checks. Finally, the redirection step occurs, where the value of a fork() call is stored in pid, and this value of pid determines child and parent process. This is where the redirect symbol loop can occur (if pid == 0); this cycles through argv2 and executes commands according to the appearance of >>, >, or <. Once this has occered, execv is run, and the loop continues for the rest of the lines of the input. 