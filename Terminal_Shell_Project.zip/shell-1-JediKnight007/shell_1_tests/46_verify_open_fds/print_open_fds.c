#include <stdlib.h>
#include <stdio.h>

int main() {
    // Prints a list of the open file descriptors for the current process
    // Should be only 0 (stdin), 1 (stdout), and 2 (stderr)
    if (system("ls /proc/$$/fd") != 0) {
        perror("system");
        exit(1);
    }
}