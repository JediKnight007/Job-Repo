#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#define BUFFER_SIZE 1024

void execute_command(char **argv);
void handle_builtin(char **argv);
void parse_input(char *input, char **argv, char **argv2);
void redirect_io(char **argv);

char *find_address(char **argv4) {
    char *token;
    int count = 0;
    while (argv4[count] != NULL) {
        if (strrchr(argv4[count], '/') != NULL) {
            token = argv4[count];
            break;
        }
        count++;
    }
    return token;
}

int main() {
    char input[BUFFER_SIZE];
    char *argv[BUFFER_SIZE / 2 + 1];
    char *argv2[BUFFER_SIZE / 2 + 1];
    ssize_t bytes_read;

    while (1) {
#ifdef PROMPT
        printf("33sh> ");
        fflush(stdout);
#endif

        memset(argv, '\0', sizeof(argv));
        memset(argv2, '\0', sizeof(argv));
        bytes_read = read(STDIN_FILENO, input, BUFFER_SIZE - 1);
        if (bytes_read < 0) {
            perror("read");
            exit(EXIT_FAILURE);
        } else if (bytes_read == 0) {
            break;
        }

        input[bytes_read] = '\0';

        if (bytes_read == 1 && input[0] == '\n') {
            continue;
        }

        parse_input(input, argv, argv2);
        char *token = find_address(argv2);

        if (argv2[0] == NULL)
            continue;
        if (strcmp(argv2[0], "exit") == 0)
            break;

        if (strcmp(argv2[0], "cd") == 0) {
            if (argv2[1] == NULL) {
                fprintf(stderr, "cd: missing argument\n");
            } else if (argv2[2] != NULL) {
                fprintf(stderr, "cd: too many argument\n");
            } else if (chdir(argv2[1]) != 0) {
                perror("cd");
            }
            continue;
        } else if (strcmp(argv2[0], "rm") == 0) {
            if (argv2[1] == NULL) {
                fprintf(stderr, "rm: missing argument\n");
            } else if (argv2[2] != NULL) {
                fprintf(stderr, "rm: too many argument\n");
            } else if (unlink(argv2[1]) != 0) {
                perror("rm");
            }
            continue;
        } else if (strcmp(argv2[0], "ln") == 0) {
            if (argv2[3] != NULL) {
                fprintf(stderr, "ln: too many argument\n");
            } else if (argv2[1] == NULL || argv2[2] == NULL) {
                fprintf(stderr, "ln: missing arguments\n");
            } else if (link(argv2[1], argv2[2]) != 0) {
                perror("ln");
            }
            continue;
        }

        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            redirect_io(argv2);
            execv(token, argv);
            perror("execv");
            exit(EXIT_FAILURE);
        } else {
            int status;
            waitpid(pid, &status, 0);
        }
    }

    return 0;
}

void parse_input(char *input, char **argv, char **argv2) {
    char *token = strtok(input, " \t\n");
    int i = 0;
    while (token != NULL) {
        argv2[i] = token;
        i++;
        token = strtok(NULL, " \t\n");
    }
    argv2[i] = NULL;
    int count = 0;
    int count2 = 0;
    int isSym = 0;
    char *temp;
    char *tok;
    char ch = 'A';
    tok = &ch;
    temp = &ch;
    while (argv2[count] != NULL) {
        tok = argv2[count];
        if (isSym == 1) {
            isSym = 0;
            count++;
            continue;
        }

        if (strcmp(tok, ">>") == 0 || strcmp(tok, ">") == 0 ||
            strcmp(tok, "<") == 0) {
            if ((strcmp(temp, ">>") == 0 || strcmp(temp, ">") == 0) &&
                (strcmp(tok, ">>") == 0 || strcmp(tok, ">") == 0)) {
                fprintf(stderr, "Too many output files\n");
            }
            isSym = 1;
            temp = tok;
            count++;
            continue;
        }

        if (strrchr(tok, '/') != NULL) {
            tok = strrchr(tok, '/') + 1;
            if (strcmp(tok, "") == 0) {
                tok = NULL;
            }
        }
        argv[count2] = tok;
        count++;
        count2++;
    }
    argv[count] = NULL;
}

void redirect_io(char **argv3) {
    int i = 0;
    while (argv3[i] != NULL) {
        if (strcmp(argv3[i], ">") == 0) {
            int fd = open(argv3[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd < 0) {
                perror("ope");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
            argv3[i] = NULL;
        } else if (strcmp(argv3[i], ">>") == 0) {
            int fd = open(argv3[i + 1], O_WRONLY | O_CREAT | O_APPEND, 0644);
            if (fd < 0) {
                perror("op");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
            argv3[i] = NULL;
        } else if (strcmp(argv3[i], "<") == 0) {
            int fd = open(argv3[i + 1], O_RDONLY);
            if (fd < 0) {
                printf("%s", argv3[i + 1]);
                perror("o");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
            argv3[i] = NULL;
        }
        i++;
    }
}
